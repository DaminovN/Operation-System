int f1() {
    return 1;
}