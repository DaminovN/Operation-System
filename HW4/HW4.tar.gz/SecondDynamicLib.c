int f3() {
    return 3;
}